package org.dcsim;

import java.util.ArrayList;
import java.util.List;

public class Main {

    record TrainState(int id, boolean isUpDirection, double position, double speed, double power) {}

    public static void main(String[] args) {
        // Editable simulation parameters
        int upTrainCount = 3;
        int upTrainHeadway = 300;             // seconds
        int upTrainStartTime = 8 * 3600;      // 08:00

        int downTrainCount = 3;
        int downTrainHeadway = 300;
        int downTrainStartTime = 8 * 3600 + 600; // 08:10

        int simulationStartTime = 8 * 3600;
        int simulationEndTime = 10 * 3600;    // 10:00

        double auxiliaryPower = 2000.0;       // Watts

        List<TrainState> activeTrains = new ArrayList<>();
        List<TrainSchedule> schedules = new ArrayList<>();

        // Generate up-train schedules
        for (int i = 0; i < upTrainCount; i++) {
            int startTime = upTrainStartTime + i * upTrainHeadway;
            schedules.add(new TrainSchedule(i, true, startTime));
        }

        // Generate down-train schedules
        for (int i = 0; i < downTrainCount; i++) {
            int startTime = downTrainStartTime + i * downTrainHeadway;
            schedules.add(new TrainSchedule(100 + i, false, startTime));
        }

        // Main simulation loop
        for (int t = simulationStartTime; t <= simulationEndTime; t += 1) {
            // Activate trains
            for (TrainSchedule schedule : schedules) {
                if (schedule.startTime == t) {
                    System.out.printf("Train %d started at time %d (dir: %s)%n",
                        schedule.id, t, schedule.isUp ? "UP" : "DOWN");
                    activeTrains.add(new TrainState(schedule.id, schedule.isUp, 0.0, 0.0, 0.0));
                }
            }

            // Update all trains
            List<TrainState> updatedTrains = new ArrayList<>();
            for (TrainState train : activeTrains) {
                TrainState updated = moveTrain(train, t);
                updatedTrains.add(updated);
            }
            activeTrains = updatedTrains;

            // TODO: Call DC solver with train states
        }

        System.out.println("Simulation complete.");
    }

    record TrainSchedule(int id, boolean isUp, int startTime) {}

    private static TrainState moveTrain(TrainState train, int t) {
        // Dummy logic: accelerate to 80 km/h, cruise for 2 min, brake
        double accel = 1.0;
        double cruiseSpeed = 22.22;
        double cruiseTime = 120.0;
        double brake = -1.0;

        double dt = 1.0; // time step
        double speed = train.speed;
        double position = train.position;
        double power = 0.0;

        double targetSpeed = cruiseSpeed;
        double updatedSpeed = speed;

        if (position < 500) {
            updatedSpeed = Math.min(speed + accel * dt, cruiseSpeed);
            power = 1200000; // 1200 kW
        } else if (position < 500 + cruiseSpeed * cruiseTime) {
            updatedSpeed = cruiseSpeed;
            power = 1200000;
        } else {
            updatedSpeed = Math.max(0, speed + brake * dt);
            power = -800000; // braking power
        }

        double updatedPosition = position + updatedSpeed * dt;

        return new TrainState(train.id, train.isUpDirection, updatedPosition, updatedSpeed, power);
    }
}
